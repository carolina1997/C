function Mostrar()
{
//tomo la edad  

var años

años=document.getElementById("edad").value;

if(años>=13&&años<=17){

	alert("Esta persona es adolescente");
}



}//FIN DE LA FUNCIÓN