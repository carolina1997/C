function Mostrar()

{
	var años
	años=document.getElementById("edad").value;

	if(años==15)
	{
		alert("niña bonita")
	}


//tomo la edad  


}//FIN DE LA FUNCIÓN