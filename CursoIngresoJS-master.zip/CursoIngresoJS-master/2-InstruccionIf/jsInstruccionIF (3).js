function Mostrar()
{
//tomo la edad  
var años
años=document.getElementById("edad").value;

if(años>=18){

	alert("Esta persona es mayor de edad")
}

else{

	alert("Esta persona es menor de edad")
}


}//FIN DE LA FUNCIÓN