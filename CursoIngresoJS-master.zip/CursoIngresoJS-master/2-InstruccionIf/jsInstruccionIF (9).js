function Mostrar()
{
	//Genero el número RANDOM entre 1 y 10 
	var numero

	numero=parseInt(Math.random()*(11-1))+1;

	alert(numero);
}//FIN DE LA FUNCIÓN