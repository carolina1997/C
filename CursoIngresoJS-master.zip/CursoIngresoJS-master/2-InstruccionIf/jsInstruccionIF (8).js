function Mostrar()
{
//tomo la edad  
var años
var ecivil

años=document.getElementById("edad").value;
ecivil=document.getElementById("estadoCivil").value;

if(años>=18&&ecivil=="Soltero"){

	alert("Es soltero y no es menor");


}

	


}//FIN DE LA FUNCIÓN