function Mostrar()
{

	var contador = 0;

	while(contador <= 10)
	{
		
		contador=contador+1;

		console.log(contador);
		
		
	}


}//FIN DE LA FUNCIÓN