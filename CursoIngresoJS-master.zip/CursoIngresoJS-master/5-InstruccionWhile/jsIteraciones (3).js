function Mostrar()
{

var clave = prompt("Ingrese la contraseña");

while(clave != "utn750")
	{
		
		clave = prompt();

	}

}//FIN DE LA FUNCIÓN
