function Mostrar()
{
	var numero = 11;

	while( numero > 1 )
		{
			numero = numero - 1;

			console.log(numero);

			

		}

	


}//FIN DE LA FUNCIÓN