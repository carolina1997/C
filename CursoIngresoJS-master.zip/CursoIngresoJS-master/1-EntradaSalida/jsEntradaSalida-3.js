/*Debemos lograr tomar un dato por 'ID'
y luego mostrarlo por 'Alert' al presionar el botón  'MOSTRAR'*/
function Mostar()
{
	var dato;

	dato=document.getElementById("elNombre").value;

	alert(dato);
}


